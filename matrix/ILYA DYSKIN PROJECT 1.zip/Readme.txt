Partially written by Ilya Dyskin

In this lab, I have made addition to the matrix.c, matrix.h, and mat_test.c files. Primarily, I have added to funcitonality to read a matrix from a given text file, ability to transpose, add, and multiply matrices together.

I have also added different error code to reflex possible errors that can appear during testing.

The files are compiled using 'make -f makefile.txt' command.

Here's the original readme file:

This directory has partial code actually written by CB 
(beware, not much of a coder!)
for C assignments for weeks  2 and 3-4.

Not supported or recommended, may be wrong.
Use your judgement to read, borrow, modify, or ignore.  

This directory has files

Readme: (this file)

index.php: (makes directory readable from a web browser, not needed for 
            the assignment)

makefile:  simple, explicit makefile.  Goal is clarity, not
           virtuosity.  creates an executable.

matrix.h, matrix_types.h:  #defines, type defs, and  struct defs for
         matrices.

matrix.c:  matrix utilities

mat_test.c:  driver to test and demonstrate utilities

sample_matrix: example human and machine-readable matrix file.

The assignment involves additions to both .c files with
whatever changes are needed to any .h files.  All details
in comments in the .c and .h files.

 
